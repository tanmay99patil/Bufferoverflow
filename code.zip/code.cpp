#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr2[30];

	for (int i = 0; i < 10; ++i) {
		arr[i] = i*i;
	}
 
        int k =0;
        for (size_t j = 0; j < 5; ++j) {
	    for (size_t m = 0; m < 10; ++m) {
		arr2[k] = arr[m];
                ++k;
 	    }
	} 
  return 0;
}